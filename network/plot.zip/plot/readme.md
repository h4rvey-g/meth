1. 这几个图的图例应该是一样的，我改了一下第一个图的，用一个就行

2. p<0.01, r的cutoff如下

   ACQ:0.680

   EXT:0.510

   PRE:0.430

   REIN:0.330

   SAL_ACQ:0.460

   SAL_EXT:0.680

   SAL_PRE:0.410

   SAL_REIN:0.330